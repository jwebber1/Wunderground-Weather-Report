/*                                                          Jonathan Webber
    Assignment 5, XML Weather Report
    Ask the user to type a state and a city. Fetch the weather for the city
requested. If there is a blank in the city name you will need to change it
to an underscore (_).
    Attempt to fetch the weather for the city and state. Either return an
appropriate message if the city is not found, or return the weather report.
*/

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

public class WeatherMain {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String stateAbbrev = "";
        String city = "";

        //error handling loop for state abbreviatio length
        while(stateAbbrev.length() != 2) {

            //getting state abbreviation from user
            System.out.print("Please enter state abbreviation: ");
            String userInputST = input.next();

            //error handling
            if (userInputST.length() == 2) {
                stateAbbrev = userInputST.toUpperCase();
            } else {
                System.out.println("Not a valid state. Please try again: ");
            }
        }//successfully retrieved stateAbbrev

        //get city from user
        System.out.print("Please enter city: ");
        input.nextLine();//throw away excess \n character
        String userInputCity = input.nextLine();
        city = formatCity(userInputCity);
        //successfully retrieved city

        //format string for the website to scrape
        String urlString = String.format(
                "http://api.wunderground.com/api/9db68defb9972483/conditions/q/%s/%s.xml",
                stateAbbrev,city);

        //get the data from the website
        String xml = readFromURL(urlString);
        Document doc = Jsoup.parse(xml,"", Parser.xmlParser());

        //Query strings for the website and error handling
        try {
            String xmlCityState = doc.select("full").first().text();
            String xmlTime = doc.select("observation_time")
                            .first().text().replaceAll("Last Updated on ", "");
            String xmlWeather = doc.select("weather").first().text().toLowerCase();
            String xmlTemperature = doc.select("temperature_string").first().text();
            String xmlWindChill = doc.select("windchill_string").first().text();
            String xmlVisMiles = doc.select("visibility_mi").first().text();
            String xmlVisKilos = doc.select("visibility_km").first().text();
            String xmlHumidity = doc.select("relative_humidity").first().text();
            String xmlWindDirection = doc.select("wind_dir").first().text();
            String xmlWindMPH = doc.select("wind_mph").first().text();
            String xmlWindKMH = doc.select("wind_kph").first().text();
            String xmlPrecipToday = doc.select("precip_today_string").first().text();
            String xmlPrecipHr = doc.select("precip_1hr_string").first().text();

            //display to the console
            System.out.printf("\nCurrent weather in %s on %s\n", xmlCityState, xmlTime);
            System.out.println("---------------------------------------------------");
            System.out.printf(">\tCurrently %s with a temperature of %s and wind chill of %s.\n",
                    xmlWeather, xmlTemperature, xmlWindChill);
            System.out.printf(">\tVisibility of %s miles (%s kilometers).\n",
                    xmlVisMiles, xmlVisKilos);
            System.out.printf(">\tRelative humidity of %s with precipitation today of %s, %s in the last hour.\n",
                    xmlHumidity, xmlPrecipToday, xmlPrecipHr);
            System.out.printf(">\tWind coming from the %s at %s mph (%s kph).\n",
                    xmlWindDirection, xmlWindMPH, xmlWindKMH);
            System.out.printf("\nWeather brought to you by Weather Underground, %s.\n", doc.select("link").first().text());
        }
        catch(NullPointerException e){
            System.out.println("Could not find given city and state or possible internet connectivity issues.");
        }
    }//end of main

    //formatter for the city string
    public static String formatCity(String str){
        String city = "";
        String temp = str.toLowerCase();

        //error handling for "st." or "st"
        if(str.startsWith("st")){
            temp = "saint"+str.substring(2);
        }
        if(str.startsWith("st.")){
            temp = "saint"+str.substring(3);
        }

        //capitalize first letter of city and after spaces
        for(int i = 0; i<temp.length(); i++){
            if(i == 0 || temp.charAt(i-1) == ' '){
                city += String.valueOf(temp.charAt(i)).toUpperCase();
            }
            else{
                city += temp.charAt(i);
            }
        }

        return city.replace(' ','_');
    }

    //method to grab info from website
    public static String readFromURL(String urlString){
        String data = "";

        try {
            URL url = new URL(urlString);
            BufferedReader input = new BufferedReader(
                    new InputStreamReader(url.openStream()));
            String str;
            while((str = input.readLine()) != null) {
                data += str;
            }
            input.close();
        }
        catch (Exception e){
            System.err.println(e.getMessage());
        }
        return data;
    }
}
