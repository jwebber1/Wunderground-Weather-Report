import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

public class WeatherMain {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String stateAbbrev = "";
        String city = "";

        while(stateAbbrev.length() != 2) {

            //getting state abbreviation from user
            System.out.print("Please enter state abbreviation: ");
            String userInputST = input.next();


            //error handling
            if (userInputST.length() == 2) {
                stateAbbrev = userInputST.toUpperCase();
            } else {
                System.out.println("Not a valid state. Please try again: ");
            }
        }//successfully retrieved stateAbbrev

        //get city from user nd replace ' ' with '_'
        System.out.print("Please enter city: ");
        input.nextLine();//throw away \n
        String userInputCity = input.nextLine();
        city = userInputCity.replace(' ','_');
        //successfully retrieved city

        //string for the website to scrape
        String urlString = String.format(
                "http://api.wunderground.com/api/9db68defb9972483/conditions/q/%s/%s.xml",
                stateAbbrev,city);

        String xml = readFromURL(urlString);

        Document doc = Jsoup.parse(xml,"", Parser.xmlParser());

        //Query strings for the website
        String xmlCityState = doc.select("full").first().text();
        String xmlTime =
                doc.select("observation_time").first().text().replaceAll("Last Updated on ","");
        String xmlWeather = doc.select("weather").first().text().toLowerCase();
        String xmlTemperature = doc.select("temperature_string").first().text();
        String xmlWindChill = doc.select("windchill_string").first().text();
        String xmlVisMiles = doc.select("visibility_mi").first().text();
        String xmlVisKilos = doc.select("visibility_km").first().text();
        String xmlHumidity = doc.select("relative_humidity").first().text();
        String xmlWindDirection = doc.select("wind_dir").first().text();
        String xmlWindMPH = doc.select("wind_mph").first().text();
        String xmlWindKMH = doc.select("wind_kph").first().text();
        String xmlPrecipToday = doc.select("precip_today_string").first().text();
        String xmlPrecipHr = doc.select("precip_1hr_string").first().text();

        //display to the console
        System.out.printf("\nCurrent weather in %s on %s\n", xmlCityState, xmlTime);
        System.out.println("---------------------------------------------------");
        System.out.printf("Currently %s outside with a temperature of %s and wind chill of %s.\n",
                xmlWeather, xmlTemperature, xmlWindChill);
        System.out.printf("Visibility of %s miles (%s kilometers).\n",
                xmlVisMiles, xmlVisKilos);
        System.out.printf("Relative humidity of %s with precipitation today of %s, %s in the last hour.\n",
                xmlHumidity, xmlPrecipToday, xmlPrecipHr);
        System.out.printf("Wind coming from the %s at %s mph (%s kph).\n",
                xmlWindDirection, xmlWindMPH, xmlWindKMH);
        System.out.printf("Weather brought to you by Weather Underground, %s.\n",doc.select("link").first().text());
    }

    public static String readFromURL(String urlString){
        String data = "";
        try {

            URL url = new URL(urlString);
            BufferedReader input = new BufferedReader(
                    new InputStreamReader(url.openStream()));
            String str;
            while((str = input.readLine()) != null) {
                data += str;
            }
            input.close();

        }
        catch (Exception e){
            System.err.println(e.getMessage());
        }

        return data;
    }
}
